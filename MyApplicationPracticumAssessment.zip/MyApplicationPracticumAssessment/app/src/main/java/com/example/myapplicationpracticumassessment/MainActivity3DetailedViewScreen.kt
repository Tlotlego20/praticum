package com.example.myapplicationpracticumassessment

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import org.w3c.dom.Text

class MainActivity3DetailedViewScreen : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main_activity3_detailed_view_screen)

        // Initialize views
        val tvMaxTemp: TextView = findViewById(R.id.MaxTemp)
        val tvMinTemp: TextView = findViewById(R.id.MinTemp)
        val tvWeatherCondition: TextView = findViewById(R.id.WeatherCondition)
        val btnBack: Button = findViewById(R.id.btnBack)

        // Retrieve data from intent
        val maxTemp = intent.getStringExtra("MAX_TEMP")
        val minTemp = intent.getStringExtra("MIN_TEMP")
        val weatherCondition = intent.getStringExtra("WEATHER_CONDITION")

        // Set data to TextViews
        tvMaxTemp.text = "Max Temp: $maxTemp"
        tvMinTemp.text = "Min Temp: $minTemp"
        tvWeatherCondition.text = "Weather Condition: $weatherCondition"

        // Set back button listener
        btnBack.setOnClickListener {
            finish() // Finish current activity and go back to the main screen
        }
    }
}