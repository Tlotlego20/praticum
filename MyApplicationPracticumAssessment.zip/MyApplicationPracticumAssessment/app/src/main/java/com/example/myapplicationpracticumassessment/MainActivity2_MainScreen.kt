package com.example.myapplicationpracticumassessment

import android.content.Intent
import android.health.connect.datatypes.units.Temperature
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

class MainActivity2_MainScreen : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main_activity2_main_screen)

        val temperature =DoubleArray(7)

        val editTextDay1 = findViewById<EditText>(R.id.editTextDay1)
        val editTextDay2 = findViewById<EditText>(R.id.editTextDay2)
        // Initialize EditTexts for other days similarly

        val btnCalculateAverage = findViewById<Button>(R.id.btnCalculateAverage)
        val tvAverageTemperature = findViewById<TextView>(R.id.AverageTemperature)
        val btnDetailView = findViewById<Button>(R.id.btnDetailView)
        val btnClearData = findViewById<Button>(R.id.btnClearData)

        btnCalculateAverage.setOnClickListener {
            val intent = Intent(this, MainActivity3DetailedViewScreen::class.java)
            temperature[0] = editTextDay1.text.toString().toDouble()
            temperature[1] = editTextDay2.text.toString().toDouble()
            // Repeat for other days

        }

        btnDetailView.setOnClickListener {
            val intent = Intent(this, MainActivity3DetailedViewScreen::class.java)
            intent.putExtra("temperatures", temperature)
            startActivity(intent)
        }

        btnClearData.setOnClickListener {
            val intent = Intent(this, MainActivity3DetailedViewScreen::class.java)
            editTextDay1.text.clear()
            editTextDay2.text.clear()
            // Clear other EditTexts similarly
            tvAverageTemperature.text = "Average Temperature: "
            finish()
        }
    }
}

